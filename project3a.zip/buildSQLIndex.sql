CREATE INDEX IEnds ON `Items`(`Ends`);
CREATE INDEX IBuy_Price ON `Items`(`Buy_Price`);
CREATE INDEX ISeller ON `Items`(`Seller`);
CREATE INDEX IBidder ON `Bids`(`UserID`);