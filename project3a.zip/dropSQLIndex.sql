DROP INDEX IEnds ON Items;
DROP INDEX IBuy_Price ON Items;
DROP INDEX ISeller ON Items;
DROP INDEX IBidder ON Bids;